import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.types import StructType, StructField, IntegerType, DoubleType

args = getResolvedOptions(sys.argv, ['JOB_NAME'])

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# -------------------
# Schema definition
# -------------------
orders_schema = StructType([
    StructField("order_id", IntegerType(), True),
    StructField("user_id", IntegerType(), True),
    StructField("order_number", IntegerType(), True),
    StructField("order_dow", IntegerType(), True),
    StructField("order_hour_of_day", IntegerType(), True),
    StructField("days_since_prior_order", DoubleType(), True)
])

# -------------------
# EXTRACT
# -------------------
df_orders = spark.read.option("header", True).schema(orders_schema).csv(
    "s3://retail-analytics-store/raw/orders/"
)

# -------------------
# TRANSFORM
# -------------------
df_orders_clean = df_orders.dropDuplicates()

# -------------------
# (optional checks)
# -------------------
df_orders_clean.printSchema()
print(df_orders_clean.count())

# -------------------
# LOAD (Silver layer)
# -------------------
df_orders_clean.write.mode("overwrite").partitionBy("order_dow").parquet(
    "s3://retail-analytics-store/processed/orders/"
)

job.commit()