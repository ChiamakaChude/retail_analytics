import os
from utils.get_env import get_env
from pyspark.sql.types import StructType, StructField, IntegerType, DoubleType, StringType


TYPE_MAPPING = {
    "integer": IntegerType(),
    "double": DoubleType(),
    "string": StringType()
}

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

DATASETS_CONFIG_PATH = os.path.join(BASE_DIR, "configs/datasets.yaml")
SCHEMAS_CONFIG_PATH = os.path.join(BASE_DIR, "configs/schemas.yaml")


DATASETS_CONFIG_PATH_S3 = "s3://retail-analytics-store/configs/datasets.yaml"
SCHEMAS_CONFIG_PATH_S3 = "s3://retail-analytics-store/configs/schemas.yaml"

ENV = get_env()
AWS_ENV_NAME = "aws"
LOCAL_ENV_NAME = "local"

print(f"Configuration base directory: {BASE_DIR}")