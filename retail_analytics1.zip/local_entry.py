# local entry point for testing and development
import os
import logging
from utils.logging import configure_logging, log_event
from etl.engine import orchestrate_pipeline
from utils.spark_factory import get_spark
from utils.config import ENV

'''
os.environ["JAVA_HOME"] = r"C:\Program Files\Java\jdk-17"
os.environ["HADOOP_HOME"] = r"C:\hadoop"
os.environ["PATH"] = os.environ["JAVA_HOME"] + r"\bin;" + os.environ["PATH"]
os.environ["PATH"] = os.environ["HADOOP_HOME"] + r"\bin;" + os.environ["PATH"]


import subprocess
result = subprocess.run(["java", "-version"], capture_output=True, text=True)
print(result.stderr)  # java version should show 17'''

configure_logging()
logger = logging.getLogger(__name__)

logger.info("Starting local entry point...Environment: %s", ENV)

spark = get_spark(env=ENV)

def run_pipeline():
    log_event(logger, "INFO", "pipeline_started")
    try:
        orchestrate_pipeline(spark)
        log_event(logger, "INFO", "pipeline_completed_successfully")
    except Exception as e:
        log_event(logger, "ERROR", "pipeline_failed", error=str(e))


if __name__ == "__main__":
    run_pipeline()